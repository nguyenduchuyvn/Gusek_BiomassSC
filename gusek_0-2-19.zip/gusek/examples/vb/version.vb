Imports System
Imports org.gnu.glpk

Public Module module1
   Sub Main()
     Console.WriteLine ("GLPK " + GLPK.glp_version())
   End Sub
End Module
